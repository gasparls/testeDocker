import { NgModule } from "@angular/core";

import { ComboComponent } from "./combo/combo.component";

@NgModule({
    declarations: [ ComboComponent ],
    exports: [ ComboComponent ]
})
export class CombosModule {}

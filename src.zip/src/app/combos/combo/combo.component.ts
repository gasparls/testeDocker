import { Component, Input } from "@angular/core";

@Component({
  selector: 'ap-combo',
  templateUrl: 'combo.component.html'
})

export class ComboComponent {
  @Input() name = '';
  @Input() id = '';
  @Input() value = '';
  @Input() texto = '';
}
